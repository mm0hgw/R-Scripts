#' Test data for munging
#'@doctype data
#'@usage
#'data(testData)
#' @description
#' Test data for your munging pleasure.
#'@examples
#'data(testData)
#'mung(testData)
"testData"

#' Test data for munging
#'@doctype data
#'@usage
#'data(testData)
#' @description
#' Test data for your munging pleasure.
#'@examples
#'data(testData)
#'mung(testData2)
"testData2"
